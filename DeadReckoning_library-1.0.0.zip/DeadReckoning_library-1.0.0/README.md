# DeadReckoning-library
This library uses dead reckoning on a differential drive Arduino robot with encoders to estimate the position of the robot real time.

The main limiation is that this library only uses wheel encoder data and assumes no wheel slipage. 
The library also assumes that the wheels only rotate forwards.
It is useful in scenarious where wheel slipage is unlikely such as a robot toy moving on a hard surface.

Documentation:
https://github.com/jaean123/DeadReckoning-library/wiki/Documentation
